grasspi
=======

To install, do::

    Download latest version from http://github.com/ylukin/grasspi
    tar zxvf grasspi-x.x.tar.gz
    cd grasspi-x.x
    python setup.py install

This will install a Python module "grasspi" into your site-packages that can now be imported into your project. 
Included is a cli module "grasspi_cli.py" that you can add to crontab to run periodically. 
